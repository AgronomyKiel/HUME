object Form1: TForm1
  Left = 265
  Top = 200
  Width = 979
  Height = 577
  Caption = 'Form1'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object PageControl1: TPageControl
    Left = 0
    Top = 33
    Width = 971
    Height = 517
    ActivePage = TabSheet1
    Align = alClient
    TabOrder = 0
    object TabSheet1: TTabSheet
      Caption = 'ChangeIniFileStrings'
      object LabelSourceDirectory: TLabel
        Left = 96
        Top = 88
        Width = 43
        Height = 13
        Caption = 'OldString'
      end
      object LabelDestDirectory: TLabel
        Left = 432
        Top = 88
        Width = 49
        Height = 13
        Caption = 'NewString'
      end
      object ButtonChange: TButton
        Left = 24
        Top = 412
        Width = 75
        Height = 25
        Caption = 'ChangeStrings'
        TabOrder = 0
        OnClick = ButtonChangeClick
      end
      object DirectoryListBoxSource: TDirectoryListBox
        Left = 96
        Top = 224
        Width = 265
        Height = 97
        ItemHeight = 16
        TabOrder = 1
        OnChange = DirectoryListBoxSourceChange
      end
      object DriveComboBoxSource: TDriveComboBox
        Left = 96
        Top = 168
        Width = 265
        Height = 19
        TabOrder = 2
        OnChange = DriveComboBoxSourceChange
      end
      object DriveComboBoxDest: TDriveComboBox
        Left = 432
        Top = 168
        Width = 265
        Height = 19
        TabOrder = 3
        OnChange = DriveComboBoxDestChange
      end
      object DirectoryListBoxDest: TDirectoryListBox
        Left = 432
        Top = 224
        Width = 265
        Height = 97
        ItemHeight = 16
        TabOrder = 4
        OnChange = DirectoryListBoxDestChange
      end
      object EditSource: TEdit
        Left = 96
        Top = 120
        Width = 265
        Height = 21
        TabOrder = 5
      end
      object EditDest: TEdit
        Left = 432
        Top = 120
        Width = 265
        Height = 21
        TabOrder = 6
      end
    end
    object TabSheetDataNames: TTabSheet
      Caption = 'ChangeDataNames'
      ImageIndex = 1
      object AdvStringGrid1: TAdvStringGrid
        Left = 0
        Top = 8
        Width = 833
        Height = 465
        ColCount = 2
        DefaultColWidth = 240
        DefaultRowHeight = 21
      end
      object ButtonLoadDataNames: TButton
        Left = 856
        Top = 16
        Width = 75
        Height = 25
        Caption = 'Load'
        TabOrder = 1
        OnClick = ButtonLoadDataNamesClick
      end
      object ButtonChangeDataVarNames: TButton
        Left = 856
        Top = 56
        Width = 75
        Height = 25
        Caption = 'Change'
        TabOrder = 2
        OnClick = ButtonChangeDataVarNamesClick
      end
    end
  end
  object Panel1: TPanel
    Left = 0
    Top = 0
    Width = 971
    Height = 33
    Align = alTop
    Caption = 'Panel1'
    TabOrder = 1
    object LabelFNFile: TLabel
      Left = 8
      Top = 12
      Width = 30
      Height = 13
      Caption = 'FNFile'
    end
    object EditFNfile: TEdit
      Left = 48
      Top = 4
      Width = 489
      Height = 21
      TabOrder = 0
    end
    object BitBtnFN: TBitBtn
      Left = 536
      Top = 0
      Width = 25
      Height = 25
      Caption = '...'
      TabOrder = 1
      OnClick = BitBtnFNClick
    end
  end
  object OpenDialog1: TOpenDialog
    Left = 888
    Top = 488
  end
end
